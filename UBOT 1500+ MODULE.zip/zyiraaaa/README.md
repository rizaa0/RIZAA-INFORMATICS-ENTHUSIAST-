# 🤖 Userbot Manager — Panduan Lengkap (Untuk Pemula)

Bot ini = **1 bot Telegram** yang ngatur banyak **userbot** (akun Telegram yang dijadiin bot). Ada sistem role berjenjang (Prem → Reseller → Admin → Owner → Tk → Ceo → Pemilik), 3000 command, panel kelola user, struk transaksi, dll. Database pakai **MongoDB**. Versi ini **tanpa Mini App** (semua lewat chat).

> Panduan ini ditulis buat yang **belum tau apa-apa**. Ikutin urut dari atas. Santai aja, gampang kok 👌

---

## 📋 DAFTAR ISI
1. Yang harus disiapkan
2. Cara dapat API Telegram
3. Cara dapat Token Bot
4. Cara dapat ID Telegram kamu (Owner)
5. Cara bikin Database MongoDB (GRATIS)
6. Cara isi file .env
7. Cara jalanin bot
8. Cara ganti tulisan menu awal
9. Cara pakai (command penting)
10. Kalau error (troubleshooting)

---

## 1. Yang harus disiapkan

Kamu butuh 4 hal (semuanya GRATIS):
- ✅ **API ID & API HASH** — dari Telegram
- ✅ **Token Bot** — dari @BotFather
- ✅ **ID Telegram kamu** — dari @userinfobot
- ✅ **Link MongoDB** — dari MongoDB Atlas (database gratis)

Plus tempat jalanin bot (panel Pterodactyl / VPS / hosting Node.js). Bot ini butuh **Node.js versi 18 ke atas**.

---

## 2. Cara dapat API Telegram

1. Buka **https://my.telegram.org** di browser
2. Login pakai **nomor HP** kamu (yang ada Telegram-nya) → masukin kode OTP yang masuk ke Telegram
3. Klik menu **"API development tools"**
4. Isi form:
   - **App title:** bebas, misal `Userbot`
   - **Short name:** bebas, misal `ubot`
   - Yang lain kosongin aja
5. Klik **Create application**
6. Nanti muncul **App api_id** (angka) dan **App api_hash** (huruf+angka panjang)
7. **Catat dua-duanya** → nanti dimasukin ke `.env`

---

## 3. Cara dapat Token Bot

1. Buka Telegram, chat **@BotFather** (yang ada centang biru)
2. Ketik `/newbot` → kirim
3. Dia tanya **nama bot** → ketik bebas, misal `Userbot Manager`
4. Dia tanya **username bot** → harus diakhiri `bot`, misal `userbotku_bot`
5. Kalau berhasil, dia kasih **token** kayak gini:
   ```
   123456789:ABCdefGhIJKlmNoPQRstuVWxyz1234567
   ```
6. **Catat token-nya** → nanti dimasukin ke `.env`

> 💡 Sekalian chat @BotFather lalu `/setprivacy` → pilih bot kamu → **Disable**. Ini biar bot bisa baca pesan di grup (kalau mau dipakai di grup).

---

## 4. Cara dapat ID Telegram kamu (Owner)

1. Chat **@userinfobot** di Telegram
2. Dia langsung bales dengan **Id:** kamu (angka, misal `1940337435`)
3. **Catat angkanya** → ini jadi `OWNER_IDS` (kamu = owner, kuasa penuh)

---

## 5. Cara bikin Database MongoDB (GRATIS)

MongoDB Atlas itu database online gratis. Ikutin pelan-pelan:

### A. Bikin akun & cluster
1. Buka **https://www.mongodb.com/atlas** → klik **Try Free** → daftar (bisa pakai Google)
2. Setelah masuk, dia minta bikin **Cluster**. Pilih yang **FREE / M0** (gratis selamanya).
3. Pilih provider & region bebas (pilih yang deket, misal Singapore). Klik **Create**.

### B. Bikin user database
1. Nanti muncul **"Security Quickstart"** atau menu **Database Access**
2. Bikin **username** & **password** (catat! jangan pakai simbol aneh di password biar gampang)
3. Klik **Create User**

### C. Izinkan akses dari mana saja (PENTING!)
1. Buka menu **Network Access** (sebelah kiri)
2. Klik **Add IP Address**
3. Klik **ALLOW ACCESS FROM ANYWHERE** → otomatis isi `0.0.0.0/0`
4. Klik **Confirm**

> ⚠️ Langkah C ini WAJIB. Kalau ga, bot ga bisa konek ke database (error timeout).

### D. Ambil link koneksi (connection string)
1. Buka menu **Database** (kiri) → klik tombol **Connect** di cluster kamu
2. Pilih **Drivers** (atau "Connect your application")
3. Pilih Driver **Node.js**
4. Nanti muncul link kayak gini:
   ```
   mongodb+srv://username:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
5. **Ganti `<password>`** dengan password yang kamu bikin di langkah B (hapus juga tanda `<` dan `>`)
6. **Catat link lengkapnya** → ini jadi `MONGODB_URI` di `.env`

Contoh hasil akhir (kalau password kamu `rahasia123`):
```
mongodb+srv://dimaz:rahasia123@cluster0.ab12c.mongodb.net/?retryWrites=true&w=majority
```

---

## 6. Cara isi file .env

File `.env` itu tempat semua pengaturan. Buka file `.env` (pakai editor di panel atau text editor), terus isi:

```
API_ID=12345678                 (dari langkah 2)
API_HASH=abcdef1234567890       (dari langkah 2)
BOT_TOKEN=123456789:ABCdef...   (dari langkah 3)
OWNER_IDS=1940337435            (dari langkah 4 = ID kamu)
OWNER_USERNAMES=@username_kamu  (username Telegram kamu)
MONGODB_URI=mongodb+srv://...   (dari langkah 5)
MONGODB_DB=ubot_manager         (biarin aja)
UBOT_PREFIX=.                   (biarin = titik)
HEADER_PHOTO=                   (link foto header, boleh kosong)
MANAGER_GROUP_IDS=              (ID grup kalau mau dipakai di grup, atau kosongin)
SERPER_API_KEY=                 (buat web search, opsional, boleh kosong)
```

> ⚠️ **ATURAN PENTING isi .env:**
> - JANGAN ada spasi sebelum/sesudah tanda `=`
> - JANGAN pakai tanda kutip (" atau ')
> - Contoh BENAR: `API_ID=12345678`
> - Contoh SALAH: `API_ID = "12345678"`

---

## 7. Cara jalanin bot

### Kalau pakai panel Pterodactyl:
1. Upload semua file bot ke panel (extract dulu, jangan upload zip-nya langsung)
2. Buka tab **Startup** → pastikan perintah jalan-nya: `node index.js`
3. Klik **Start** → panel otomatis `npm install` (install yang dibutuhin) terus jalanin bot
4. Tunggu sampai muncul di console:
   ```
   ✅ [mongo] Terkoneksi ke database "ubot_manager"
   ✅ Bot Manager aktif: @namabotmu
   📦 PLUGIN LOADED: ... command total
   ```
5. Kalau muncul itu = **BERHASIL!** 🎉 Chat bot kamu, ketik `/start`

### Kalau pakai komputer / VPS sendiri:
```
npm install
node index.js
```

---

## 8. Cara ganti tulisan menu awal

Tulisan yang muncul pas user ketik `/start` ada di file **`index.js`**, di fungsi **`buildWelcome`** (sekitar **baris 84**).

Cari bagian ini:
```js
function buildWelcome(userName, role) {
  const line = "⏣─────────────────⏣";
  return (
    `✦ ʜᴀʟᴏ <b>${esc(userName)}</b> ✦\n` +
    `${line}\n\n` +
    `⚡ <b>${esc(BOT_USERNAME)}</b> ᴀᴅᴀʟᴀʜ ʙᴏᴛ ᴘᴇɴʏᴇᴅɪᴀ ᴜsᴇʀʙᴏᴛ ...\n\n` +
    `🚀 ᴅᴇɴɢᴀɴ sɪsᴛᴇᴍ ᴍᴜʟᴛɪ-ʀᴏʟᴇ ʙᴇʀᴊᴇɴᴊᴀɴɢ, ...\n\n` +
    `💎 <b>ᴄᴀʀᴀ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ᴀᴋsᴇs:</b>\n` +
    `...\n\n` +
    `👤 ʀᴏʟᴇ ᴋᴀᴍᴜ: <b>${ROLE_LABEL[role]}</b>\n` +
    `${line}\n` +
    `📌 ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ᴜɴᴛᴜᴋ ᴍᴇʟᴀɴᴊᴜᴛᴋᴀɴ ⬇️`
  );
}
```

**Yang BOLEH kamu ubah:** cuma **kata-katanya** aja. Contoh ganti baris pertama:
```js
    `✦ Selamat datang <b>${esc(userName)}</b> di toko kami ✦\n` +
```

**JANGAN diubah / dihapus** bagian ini (nanti error):
- Tanda backtick di awal & akhir baris (karakter ` )
- `\n` (artinya: ganti baris)
- `${esc(userName)}` → otomatis jadi nama user
- `${esc(BOT_USERNAME)}` → otomatis jadi username bot
- `${ROLE_LABEL[role]}` → otomatis jadi role user (Owner/Premium/dll)
- Tanda `+` di akhir tiap baris
- `<b>` dan `</b>` → bikin tulisan tebal

### Tentang huruf kecil aneh (ʜᴀʟᴏ, ᴀᴅᴀʟᴀʜ)
Itu namanya font **smallcaps**. Kamu BOLEH ganti pakai huruf biasa kok:
```js
    `✦ HALO <b>${esc(userName)}</b> ✦\n` +
```
Atau kalau mau tetap gaya smallcaps, bikin di website **lingojam.com** (cari "Small Caps Generator") → ketik teks → salin hasilnya ke sini.

> 💡 Setelah ngedit `index.js`, **restart bot** biar perubahan kepasang.

### Ganti harga di menu "Beli Akses"
Cari fungsi `showTab` di `index.js` (cari kata `tab_beli`). Di situ ada teks harga, tinggal ganti angkanya.

---

## 9. Cara pakai (command penting)

Command di bawah diketik ke **bot manager** (bukan ke userbot):

| Command | Fungsi | Siapa yang bisa |
|---------|--------|-----------------|
| `/start` | Buka menu utama | Semua |
| `/connect` | Sambungkan userbot (lewat OTP) | Premium ke atas |
| `/myubot` | Lihat status ubot kamu | Premium ke atas |
| `/addprem <id> <hari>` | Tambah user Premium | Reseller ke atas |
| `/addreseller <id> <hari>` | Tambah Reseller | Admin ke atas |
| `/addadmin <id> <hari>` | Tambah Admin | Owner ke atas |
| `/addowner <id> <hari>` | Tambah Owner | Tk ke atas |
| `/addtk <id> <hari>` | Tambah Tk | Ceo ke atas |
| `/addceo <id> <hari>` | Tambah Ceo | Pemilik |
| `/listprem` | Lihat daftar user | Reseller ke atas |

### Panel Kelola User (lebih gampang)
Di menu `/start`, ada tombol **"{Role} Menu — Kelola User"** (cuma muncul buat Reseller/Admin/Owner). Klik itu:
- Muncul **daftar user** yang kamu tambahin (nama, ID, role, sisa hari)
- **Tap user** → ada tombol **Extend** (perpanjang hari) & **Stop** (jadiin user biasa)
- Semua ada **konfirmasi** dulu sebelum dijalankan

### Userbot (setelah connect)
Setelah user `/connect`, mereka ketik command di akun mereka sendiri pakai prefix `.` (titik):
- Command role nyesuai jabatan. Contoh kalau **Reseller**: cuma ada `.addprem`, `.extend`, `.remove` (remove cuma role di bawah kamu). Kalau **Admin**: nambah `.addreseller`. Naik terus sampai Ceo bisa `.addtk`.
- `.done produk,harga,bayar` → bikin struk transaksi (gambar)
- `.addtesti <@channel/id/link>` → set channel testimoni dulu (akun kamu harus join channel itu)
- `.sharetrx <nomor>` → forward struk transaksi itu ke channel testimoni
- `.sharetrx` (sambil **reply** sebuah pesan) → forward pesan yang di-reply ke channel
- 🎮 <b>Game</b>: ketik `.gamemenu` buat lihat semua game. Game party (grup) join-nya ketik <b>Bergabung</b>, host `.mulai` / `.batal`.
- 📝 <b>Note</b>: `.addnote nama, isi` (atau reply), `.note nama/nomor`, `.listnote`, `.editnote`, `.delnote`. Nama note unik per user.
- `.help` → lihat semua 3000 command

---

## 10. Kalau error (troubleshooting)

**[mongo] GAGAL konek / timeout**
→ Cek: (1) `MONGODB_URI` di `.env` udah bener & `<password>` udah diganti? (2) Di MongoDB Atlas → **Network Access** udah **Allow from anywhere (0.0.0.0/0)**? Ini penyebab paling sering.

**Bot ga bales `/start`**
→ Cek `BOT_TOKEN` bener? Bot udah di-Start di panel? Lihat console ada error apa.

**`/start` di grup ga bales**
→ Matiin privacy mode bot: @BotFather → `/setprivacy` → pilih bot → **Disable**. Dan pastikan ID grup udah dimasukin ke `MANAGER_GROUP_IDS` di `.env`.

**Bot bales 2x**
→ Berarti bot jalan di 2 tempat sekaligus. Matiin salah satunya, sisain 1 aja. Lihat console: kalau baris `🤖 INSTANCE` muncul 2x = ada 2 proses.

**Command userbot ilang setelah upload**
→ Upload ga komplit. Upload ulang SEMUA file (extract penuh, jangan satu-satu). Lihat console baris `📦 PLUGIN LOADED` — harusnya banyak command (300+).

**MODULE_NOT_FOUND**
→ Ada file yang ga keupload, atau `npm install` belum jalan. Restart panel (auto npm install), atau jalanin `npm install` manual.

---

## 📞 Catatan
- Data (user, role, session, transaksi) disimpan di **MongoDB**, jadi aman walau pindah panel/hosting — tinggal pakai `MONGODB_URI` yang sama.
- Owner diatur di `.env` (`OWNER_IDS`), bukan di kode. Ganti dengan ID kamu.
- Bot ini **tidak pakai web/mini app** — semua lewat chat Telegram.

Selamat pakai! 🚀

---

## 🔥 Khusus Versi Firebase (kalau kamu pakai zip `ubot-manager-firebase`)

Versi Firebase sama persis fiturnya, beda di **database** + ada **Mini App**.

**Database (ganti langkah 5 MongoDB):**
1. Buka https://console.firebase.google.com → bikin project
2. Menu **Realtime Database** → **Create Database** → mode **test** (atau set rules `.read/.write: true`)
3. Salin URL-nya (bentuk `https://xxx-default-rtdb.firebaseio.com`)
4. Di `.env`:
   ```
   DB_TYPE=firebase
   FIREBASE_DB_URL=https://xxx-default-rtdb.firebaseio.com
   ```

**Mini App:** lihat folder `miniapp/` → ada panduan deploy ke Cloudflare Workers. Setelah dapat URL, isi `MINIAPP_URL=` di `.env`. Tombol "Open" bakal muncul di bot.

> Versi MongoDB **tidak ada** Mini App (biarin `MINIAPP_URL` kosong).

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xkmmi0494", "kmmi", 494)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xc2f0492", "c2f", 492)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xhexenc0291", "hexenc", 291)];

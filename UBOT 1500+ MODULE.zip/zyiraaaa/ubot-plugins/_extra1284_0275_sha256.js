const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsha2560275", "sha256", 275)];

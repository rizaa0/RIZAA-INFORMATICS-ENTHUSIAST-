const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xhexdec0412", "hexdec", 412)];

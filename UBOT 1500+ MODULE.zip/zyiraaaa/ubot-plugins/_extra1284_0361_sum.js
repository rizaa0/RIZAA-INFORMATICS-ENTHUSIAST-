const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsum0361", "sum", 361)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmedian0125", "median", 125)];

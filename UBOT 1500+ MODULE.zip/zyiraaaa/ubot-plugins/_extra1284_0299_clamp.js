const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xclamp0299", "clamp", 299)];

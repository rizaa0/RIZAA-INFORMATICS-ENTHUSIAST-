const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrandom0320", "random", 320)];

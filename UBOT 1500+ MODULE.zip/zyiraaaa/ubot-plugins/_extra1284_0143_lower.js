const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xlower0143", "lower", 143)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsortnum0306", "sortnum", 306)];

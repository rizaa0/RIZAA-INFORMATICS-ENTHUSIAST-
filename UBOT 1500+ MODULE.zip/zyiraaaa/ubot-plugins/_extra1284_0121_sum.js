const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsum0121", "sum", 121)];

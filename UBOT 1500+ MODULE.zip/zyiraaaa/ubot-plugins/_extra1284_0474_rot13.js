const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrot130474", "rot13", 474)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xincm0079", "incm", 79)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xceil0300", "ceil", 300)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcount0206", "count", 206)];

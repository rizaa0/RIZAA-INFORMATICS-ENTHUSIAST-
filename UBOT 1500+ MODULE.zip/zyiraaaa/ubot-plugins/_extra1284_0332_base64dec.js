const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbase64dec0332", "base64dec", 332)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpercent0067", "percent", 67)];

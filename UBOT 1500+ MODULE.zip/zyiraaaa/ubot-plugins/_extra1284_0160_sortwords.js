const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsortwords0160", "sortwords", 160)];

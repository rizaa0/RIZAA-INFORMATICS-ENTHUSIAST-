const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xkmmi0374", "kmmi", 374)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrot130354", "rot13", 354)];

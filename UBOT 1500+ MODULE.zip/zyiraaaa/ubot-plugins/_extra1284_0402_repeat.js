const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrepeat0402", "repeat", 402)];

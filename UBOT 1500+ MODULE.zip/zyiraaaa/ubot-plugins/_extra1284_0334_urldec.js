const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xurldec0334", "urldec", 334)];

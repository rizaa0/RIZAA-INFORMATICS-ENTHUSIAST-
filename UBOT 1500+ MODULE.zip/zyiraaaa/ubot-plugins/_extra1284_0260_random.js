const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrandom0260", "random", 260)];

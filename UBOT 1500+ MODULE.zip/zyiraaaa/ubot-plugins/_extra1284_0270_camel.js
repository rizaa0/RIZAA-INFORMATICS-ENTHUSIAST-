const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcamel0270", "camel", 270)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsha2560035", "sha256", 35)];

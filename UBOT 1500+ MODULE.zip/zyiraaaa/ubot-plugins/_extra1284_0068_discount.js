const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xdiscount0068", "discount", 68)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmd50156", "md5", 156)];

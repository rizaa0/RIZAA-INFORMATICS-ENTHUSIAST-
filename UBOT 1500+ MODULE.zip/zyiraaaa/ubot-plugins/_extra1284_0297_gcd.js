const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xgcd0297", "gcd", 297)];

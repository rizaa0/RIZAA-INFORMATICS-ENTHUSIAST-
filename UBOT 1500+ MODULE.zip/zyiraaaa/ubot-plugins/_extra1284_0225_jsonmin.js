const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xjsonmin0225", "jsonmin", 225)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbase64enc0031", "base64enc", 31)];

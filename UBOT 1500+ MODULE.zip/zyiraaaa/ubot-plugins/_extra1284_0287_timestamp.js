const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xtimestamp0287", "timestamp", 287)];

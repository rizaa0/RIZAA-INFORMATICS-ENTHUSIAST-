const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpercent0427", "percent", 427)];

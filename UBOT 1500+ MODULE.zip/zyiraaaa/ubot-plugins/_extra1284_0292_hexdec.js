const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xhexdec0292", "hexdec", 292)];

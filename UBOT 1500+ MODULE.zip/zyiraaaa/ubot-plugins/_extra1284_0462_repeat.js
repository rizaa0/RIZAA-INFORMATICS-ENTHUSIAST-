const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrepeat0462", "repeat", 462)];

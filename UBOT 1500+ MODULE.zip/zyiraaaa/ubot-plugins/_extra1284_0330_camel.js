const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcamel0330", "camel", 330)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xf2c0193", "f2c", 193)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xclamp0119", "clamp", 119)];

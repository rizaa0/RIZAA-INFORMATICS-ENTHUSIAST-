const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrepeat0042", "repeat", 42)];

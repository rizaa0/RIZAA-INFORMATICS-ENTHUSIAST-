const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xkglb0076", "kglb", 76)];

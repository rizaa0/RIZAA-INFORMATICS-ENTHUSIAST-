const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xslug0028", "slug", 28)];

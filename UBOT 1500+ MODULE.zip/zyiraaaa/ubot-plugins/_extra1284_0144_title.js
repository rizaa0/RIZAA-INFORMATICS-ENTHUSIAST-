const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xtitle0144", "title", 144)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xurldec0274", "urldec", 274)];

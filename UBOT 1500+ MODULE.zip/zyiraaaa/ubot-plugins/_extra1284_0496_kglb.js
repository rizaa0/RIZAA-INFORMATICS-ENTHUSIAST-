const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xkglb0496", "kglb", 496)];

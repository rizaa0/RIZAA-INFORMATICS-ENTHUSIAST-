const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpassword0230", "password", 230)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcompound0056", "compound", 56)];

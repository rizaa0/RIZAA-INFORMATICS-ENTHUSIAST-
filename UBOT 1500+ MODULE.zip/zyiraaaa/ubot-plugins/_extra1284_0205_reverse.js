const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xreverse0205", "reverse", 205)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcmin0078", "cmin", 78)];

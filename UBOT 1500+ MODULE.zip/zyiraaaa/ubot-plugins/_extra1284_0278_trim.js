const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xtrim0278", "trim", 278)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrule30130", "rule3", 130)];

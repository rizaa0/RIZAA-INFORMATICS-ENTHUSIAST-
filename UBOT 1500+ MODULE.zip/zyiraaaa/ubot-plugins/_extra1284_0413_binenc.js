const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbinenc0413", "binenc", 413)];

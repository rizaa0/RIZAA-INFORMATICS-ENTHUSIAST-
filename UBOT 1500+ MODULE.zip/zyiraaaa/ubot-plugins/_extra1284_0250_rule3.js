const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrule30250", "rule3", 250)];

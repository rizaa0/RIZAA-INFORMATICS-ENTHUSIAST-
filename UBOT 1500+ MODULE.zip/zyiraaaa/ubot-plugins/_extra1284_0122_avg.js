const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xavg0122", "avg", 122)];

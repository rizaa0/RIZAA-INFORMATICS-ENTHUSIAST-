const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xclamp0239", "clamp", 239)];

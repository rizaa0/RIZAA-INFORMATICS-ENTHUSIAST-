const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmax0304", "max", 304)];

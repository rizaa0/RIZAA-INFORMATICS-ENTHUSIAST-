const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xceil0240", "ceil", 240)];

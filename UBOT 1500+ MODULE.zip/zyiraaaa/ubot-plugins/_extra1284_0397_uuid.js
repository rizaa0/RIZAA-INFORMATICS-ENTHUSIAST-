const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xuuid0397", "uuid", 397)];

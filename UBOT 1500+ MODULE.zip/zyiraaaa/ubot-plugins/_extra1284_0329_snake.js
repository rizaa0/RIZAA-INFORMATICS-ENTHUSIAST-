const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsnake0329", "snake", 329)];

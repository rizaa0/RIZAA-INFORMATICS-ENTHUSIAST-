const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xjsonpretty0286", "jsonpretty", 286)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xwordcount0087", "wordcount", 87)];

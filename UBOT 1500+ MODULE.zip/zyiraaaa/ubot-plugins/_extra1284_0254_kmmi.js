const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xkmmi0254", "kmmi", 254)];

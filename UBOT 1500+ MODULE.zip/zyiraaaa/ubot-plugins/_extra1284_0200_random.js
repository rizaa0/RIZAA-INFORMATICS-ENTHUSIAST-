const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrandom0200", "random", 200)];

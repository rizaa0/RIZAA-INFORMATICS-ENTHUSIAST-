const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xchoose0381", "choose", 381)];

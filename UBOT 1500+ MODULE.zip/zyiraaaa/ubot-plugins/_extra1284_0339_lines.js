const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xlines0339", "lines", 339)];

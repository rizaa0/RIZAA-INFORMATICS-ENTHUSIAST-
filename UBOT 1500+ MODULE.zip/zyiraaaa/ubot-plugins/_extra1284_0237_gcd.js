const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xgcd0237", "gcd", 237)];

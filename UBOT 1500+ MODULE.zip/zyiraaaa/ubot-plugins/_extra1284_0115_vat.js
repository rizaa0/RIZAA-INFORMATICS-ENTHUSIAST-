const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xvat0115", "vat", 115)];

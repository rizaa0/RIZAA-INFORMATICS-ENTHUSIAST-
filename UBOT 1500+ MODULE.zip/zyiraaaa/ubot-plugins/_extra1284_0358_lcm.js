const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xlcm0358", "lcm", 358)];

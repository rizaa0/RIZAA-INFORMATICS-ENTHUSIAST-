const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xincm0319", "incm", 319)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpassword0170", "password", 170)];

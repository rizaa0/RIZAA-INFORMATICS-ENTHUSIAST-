const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrandom0080", "random", 80)];

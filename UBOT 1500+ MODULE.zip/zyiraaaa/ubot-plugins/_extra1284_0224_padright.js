const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xpadright0224", "padright", 224)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xwordcount0267", "wordcount", 267)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xvat0175", "vat", 175)];

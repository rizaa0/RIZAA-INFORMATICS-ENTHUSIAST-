const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcompound0176", "compound", 176)];

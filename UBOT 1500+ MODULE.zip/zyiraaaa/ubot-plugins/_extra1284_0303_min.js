const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmin0303", "min", 303)];

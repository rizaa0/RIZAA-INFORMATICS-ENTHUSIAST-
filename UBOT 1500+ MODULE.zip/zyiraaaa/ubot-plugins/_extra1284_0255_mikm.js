const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmikm0255", "mikm", 255)];

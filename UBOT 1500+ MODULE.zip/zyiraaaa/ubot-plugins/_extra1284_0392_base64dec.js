const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbase64dec0392", "base64dec", 392)];

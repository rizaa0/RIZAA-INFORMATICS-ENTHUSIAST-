const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmax0424", "max", 424)];

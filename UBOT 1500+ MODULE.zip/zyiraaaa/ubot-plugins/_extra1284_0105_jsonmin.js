const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xjsonmin0105", "jsonmin", 105)];

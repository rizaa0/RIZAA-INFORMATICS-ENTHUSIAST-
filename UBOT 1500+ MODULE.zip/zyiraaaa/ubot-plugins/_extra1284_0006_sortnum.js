const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsortnum0006", "sortnum", 6)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcount0266", "count", 266)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsortwords0100", "sortwords", 100)];

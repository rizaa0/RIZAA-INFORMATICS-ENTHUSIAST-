const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsha2560335", "sha256", 335)];

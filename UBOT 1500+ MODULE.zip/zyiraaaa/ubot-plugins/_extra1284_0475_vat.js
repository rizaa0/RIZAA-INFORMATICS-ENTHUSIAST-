const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xvat0475", "vat", 475)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsortwords0340", "sortwords", 340)];

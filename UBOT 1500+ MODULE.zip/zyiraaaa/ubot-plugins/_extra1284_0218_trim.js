const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xtrim0218", "trim", 218)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xc2f0132", "c2f", 132)];

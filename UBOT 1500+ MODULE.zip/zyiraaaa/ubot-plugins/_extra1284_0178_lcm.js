const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xlcm0178", "lcm", 178)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xcompound0416", "compound", 416)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xwordcount0387", "wordcount", 387)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmarkup0489", "markup", 489)];

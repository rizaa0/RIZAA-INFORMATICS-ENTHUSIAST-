const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsha2560155", "sha256", 155)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xrot130294", "rot13", 294)];

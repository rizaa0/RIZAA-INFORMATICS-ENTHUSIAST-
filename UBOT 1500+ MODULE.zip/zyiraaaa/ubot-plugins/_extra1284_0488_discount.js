const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xdiscount0488", "discount", 488)];

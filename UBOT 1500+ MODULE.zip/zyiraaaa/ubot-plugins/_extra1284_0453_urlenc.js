const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xurlenc0453", "urlenc", 453)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsortwords0400", "sortwords", 400)];

const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xjsonpretty0226", "jsonpretty", 226)];

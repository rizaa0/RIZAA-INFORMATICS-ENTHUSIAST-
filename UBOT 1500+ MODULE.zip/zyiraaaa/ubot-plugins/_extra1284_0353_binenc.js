const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xbinenc0353", "binenc", 353)];

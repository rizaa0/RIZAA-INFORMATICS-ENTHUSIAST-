const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xsha2560215", "sha256", 215)];

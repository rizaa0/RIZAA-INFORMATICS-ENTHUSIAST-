const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xkmmi0014", "kmmi", 14)];

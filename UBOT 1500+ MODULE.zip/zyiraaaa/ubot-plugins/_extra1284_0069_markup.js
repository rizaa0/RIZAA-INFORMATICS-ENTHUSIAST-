const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xmarkup0069", "markup", 69)];

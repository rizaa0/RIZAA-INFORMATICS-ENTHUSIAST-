const extra = require("../lib/extra1284Tools");
module.exports.commands = [extra.command("xuniquewords0401", "uniquewords", 401)];

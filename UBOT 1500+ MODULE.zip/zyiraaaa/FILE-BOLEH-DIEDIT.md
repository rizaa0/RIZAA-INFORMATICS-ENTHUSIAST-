# 📄 Panduan Edit File — MyUbot Manager

Supaya lisensi kamu **tidak mati** saat kustomisasi, perhatikan pembagian file berikut.

## 🟢 BOLEH diedit (branding / tampilan / teks)
Edit sepuasnya — **tidak** memicu cek integritas:

- `index.js` — teks `/start`, `/help`, menu, branding bot manager
- `ubot-plugins/*.js` — teks & isi command ubot (mis. sambutan, `.help`, `.about`)
- `assets/` — logo, gambar, font
- `.env`, `README.md`, `config` — pengaturan
- file lain yang **bukan** daftar 🔴 di bawah

> Mau tandai file baru sebagai boleh-diedit? Taruh komentar `// @editable` di baris paling atas.

## 🔴 TIDAK boleh diedit (inti keamanan/lisensi)
Kalau file ini diubah walau 1 karakter → **Integrity Failed → panel OFF** (non-destruktif, tidak menghapus apa pun):

- `lib/gate.js` — gerbang lisensi
- `lib/integrity.js` — cek integritas
- `lib/session.js` — 1 key = 1 panel
- `lib/hwid.js` — pengunci mesin
- `lib/buildinfo.js` — penanda build
- `lib/ubotManager.js` — mesin ubot
- `lib/secureUpdate.js` — verifikasi update
- `manifest.sig.json` — daftar hash bertanda tangan

> Mau kunci file tambahan? Taruh komentar `// @protected` di baris paling atas, lalu re-sign manifest.

## ⚠️ Kalau butuh ubah yang 🔴
Hubungi penjual. Perubahan inti keamanan harus di-**re-sign** ulang oleh pemilik kunci
(pakai `make-manifest.js`). Ini sengaja — biar pembajak tidak bisa mem-patch gerbang lisensi.

Analoginya seperti WordPress: kamu bebas ganti theme, plugin, CSS, template —
tapi tidak bebas mengubah core license & signature-nya.
